"use server"

import { db } from "@/lib/db"
import { systemSettings, organizations } from "@/lib/db/schema"
import { eq, and } from "drizzle-orm"
import { revalidatePath } from "next/cache"
import { getServerSession } from "@/lib/session"
import { requireAdmin } from "@/lib/rbac"

export interface AISettings {
    enabled: boolean
    provider: "gemini" | "deepseek"
    systemPrompt?: string
}

export interface MembershipSettings {
    registrationEnabled: boolean
    recommendationRequired: boolean
}

const DEFAULT_AI_SETTINGS: AISettings = {
    enabled: true,
    provider: "deepseek", // Set as default per user request
    systemPrompt: ""
}

const DEFAULT_MEMBERSHIP_SETTINGS: MembershipSettings = {
    registrationEnabled: true,
    recommendationRequired: false
}

export interface YearPlannerSettings {
    programYearStart: Date
    programYearEnd: Date
    submissionDeadline: Date
}

const DEFAULT_YEAR_PLANNER_SETTINGS: YearPlannerSettings = {
    programYearStart: new Date(new Date().getFullYear(), 0, 1), // Jan 1
    programYearEnd: new Date(new Date().getFullYear(), 11, 31), // Dec 31
    submissionDeadline: new Date(new Date().getFullYear(), 11, 12) // Dec 12
}

export async function getAISettings(): Promise<AISettings> {
    const session = await getServerSession()
    if (!session?.user) return DEFAULT_AI_SETTINGS // Safe default for unauth (though UI is protected)

    try {
        const settings = await db.select().from(systemSettings).where(eq(systemSettings.category, "AI"))

        // Map individual rows to a config object
        const config: any = { ...DEFAULT_AI_SETTINGS }

        settings.forEach(s => {
            if (s.settingKey === "ai_enabled") config.enabled = s.settingValue === "true"
            if (s.settingKey === "ai_provider") config.provider = s.settingValue
            if (s.settingKey === "ai_system_prompt") config.systemPrompt = s.settingValue
        })

        return config
    } catch (error) {
        console.error("Failed to fetch AI settings (DB Error), using defaults:", error);
        return DEFAULT_AI_SETTINGS;
    }
}

export async function updateAISettings(data: AISettings) {
    const session = await getServerSession()
    if (!session?.user?.id) {
        throw new Error("Unauthorized")
    }
    requireAdmin(session) // Ensure only admins can change this

    // Helper to upsert a setting
    const upsertSetting = async (key: string, value: string) => {
        const existing = await db.select().from(systemSettings).where(eq(systemSettings.settingKey, key))
        if (existing.length > 0) {
            await db.update(systemSettings)
                .set({ settingValue: value, updatedBy: session.user.id })
                .where(eq(systemSettings.settingKey, key))
        } else {
            await db.insert(systemSettings).values({
                settingKey: key,
                settingValue: value,
                category: "AI",
                updatedBy: session.user.id
            })
        }
    }

    await upsertSetting("ai_enabled", String(data.enabled))
    await upsertSetting("ai_provider", data.provider)
    if (data.systemPrompt !== undefined) {
        await upsertSetting("ai_system_prompt", data.systemPrompt || "")
    }

    revalidatePath("/dashboard/admin/settings")
    return { success: true }
}

export async function getMembershipSettings(): Promise<MembershipSettings> {
    const session = await getServerSession()
    if (!session?.user) return DEFAULT_MEMBERSHIP_SETTINGS

    try {
        const settings = await db.select().from(systemSettings).where(eq(systemSettings.category, "GENERAL"))

        const config: MembershipSettings = { ...DEFAULT_MEMBERSHIP_SETTINGS }

        settings.forEach(s => {
            if (s.settingKey === "membership_registration_enabled") config.registrationEnabled = s.settingValue === "true"
            if (s.settingKey === "membership_recommendation_required") config.recommendationRequired = s.settingValue === "true"
        })

        return config
    } catch (error) {
        console.error("Failed to fetch membership settings:", error);
        return DEFAULT_MEMBERSHIP_SETTINGS;
    }
}

export async function updateMembershipSettings(data: MembershipSettings) {
    const session = await getServerSession()
    if (!session?.user?.id) {
        throw new Error("Unauthorized")
    }
    requireAdmin(session)

    const upsertSetting = async (key: string, value: string) => {
        const existing = await db.select().from(systemSettings).where(eq(systemSettings.settingKey, key))
        if (existing.length > 0) {
            await db.update(systemSettings)
                .set({ settingValue: value, updatedBy: session.user.id })
                .where(eq(systemSettings.settingKey, key))
        } else {
            await db.insert(systemSettings).values({
                settingKey: key,
                settingValue: value,
                category: "GENERAL",
                updatedBy: session.user.id
            })
        }
    }

    await upsertSetting("membership_registration_enabled", String(data.registrationEnabled))
    await upsertSetting("membership_recommendation_required", String(data.recommendationRequired))

    revalidatePath("/dashboard/admin/settings")
    return { success: true }
}

export async function getYearPlannerSettings(): Promise<YearPlannerSettings> {
    const session = await getServerSession()
    if (!session?.user) return DEFAULT_YEAR_PLANNER_SETTINGS

    try {
        const settings = await db.select().from(systemSettings).where(eq(systemSettings.category, "GENERAL"))

        const config: YearPlannerSettings = { ...DEFAULT_YEAR_PLANNER_SETTINGS }

        settings.forEach(s => {
            if (s.settingKey === "year_planner_start") config.programYearStart = new Date(s.settingValue as string)
            if (s.settingKey === "year_planner_end") config.programYearEnd = new Date(s.settingValue as string)
            if (s.settingKey === "year_planner_deadline") config.submissionDeadline = new Date(s.settingValue as string)
        })

        return config
    } catch (error) {
        return DEFAULT_YEAR_PLANNER_SETTINGS
    }
}

export async function updateYearPlannerSettings(data: YearPlannerSettings) {
    const session = await getServerSession()
    if (!session?.user?.id) throw new Error("Unauthorized")
    requireAdmin(session)

    const upsertSetting = async (key: string, value: string) => {
        const existing = await db.select().from(systemSettings).where(eq(systemSettings.settingKey, key))
        if (existing.length > 0) {
            await db.update(systemSettings)
                .set({ settingValue: value, updatedBy: session.user.id })
                .where(eq(systemSettings.settingKey, key))
        } else {
            await db.insert(systemSettings).values({
                settingKey: key,
                settingValue: value,
                category: "GENERAL",
                updatedBy: session.user.id
            })
        }
    }

    await upsertSetting("year_planner_start", data.programYearStart.toISOString())
    await upsertSetting("year_planner_end", data.programYearEnd.toISOString())
    await upsertSetting("year_planner_deadline", data.submissionDeadline.toISOString())

    revalidatePath("/dashboard/admin/settings")
    return { success: true }
}
export async function updateOrganizationProfile(data: {
    name: string,
    email: string,
    phone: string,
    website: string,
    welcomeMessage: string
}) {
    const session = await getServerSession()
    if (!session?.user?.id) throw new Error("Unauthorized")
    requireAdmin(session)

    // Update the National Organization
    await db.update(organizations)
        .set({
            name: data.name,
            email: data.email,
            phone: data.phone,
            website: data.website,
            welcomeMessage: data.welcomeMessage,
            updatedAt: new Date()
        })
        .where(eq(organizations.level, "NATIONAL"))

    revalidatePath("/dashboard/admin/settings")
    return { success: true }
}

export interface LiveKitSettings {
    url: string
    apiKey: string
    apiSecret: string
}

const DEFAULT_LIVEKIT_SETTINGS: LiveKitSettings = {
    url: "",
    apiKey: "",
    apiSecret: ""
}

export async function getLiveKitSettings(): Promise<LiveKitSettings> {
    const session = await getServerSession()
    if (!session?.user) return DEFAULT_LIVEKIT_SETTINGS

    try {
        const settings = await db.select().from(systemSettings).where(eq(systemSettings.category, "INTEGRATION"))

        const config: LiveKitSettings = { ...DEFAULT_LIVEKIT_SETTINGS }

        settings.forEach(s => {
            if (s.settingKey === "livekit_url") config.url = s.settingValue || ""
            if (s.settingKey === "livekit_api_key") config.apiKey = s.settingValue || ""
            if (s.settingKey === "livekit_api_secret") config.apiSecret = s.settingValue || ""
        })

        return config
    } catch (error) {
        return DEFAULT_LIVEKIT_SETTINGS
    }
}

export async function updateLiveKitSettings(data: LiveKitSettings) {
    const session = await getServerSession()
    if (!session?.user?.id) throw new Error("Unauthorized")
    requireAdmin(session)

    const upsertSetting = async (key: string, value: string) => {
        const existing = await db.select().from(systemSettings).where(eq(systemSettings.settingKey, key))
        if (existing.length > 0) {
            await db.update(systemSettings)
                .set({ settingValue: value, updatedBy: session.user.id })
                .where(eq(systemSettings.settingKey, key))
        } else {
            await db.insert(systemSettings).values({
                settingKey: key,
                settingValue: value,
                category: "INTEGRATION",
                updatedBy: session.user.id
            })
        }
    }

    await upsertSetting("livekit_url", data.url)
    await upsertSetting("livekit_api_key", data.apiKey)
    await upsertSetting("livekit_api_secret", data.apiSecret)

    revalidatePath("/dashboard/admin/settings")
    return { success: true }
}

export interface FinancialSettings {
    burialVerificationFee: number
}

const DEFAULT_FINANCIAL_SETTINGS: FinancialSettings = {
    burialVerificationFee: 10000
}

export async function getFinancialSettings(): Promise<FinancialSettings> {
    const session = await getServerSession()
    if (!session?.user) return DEFAULT_FINANCIAL_SETTINGS

    try {
        const settings = await db.select().from(systemSettings).where(eq(systemSettings.category, "GENERAL"))
        const config: FinancialSettings = { ...DEFAULT_FINANCIAL_SETTINGS }

        settings.forEach(s => {
            if (s.settingKey === "burial_verification_fee") config.burialVerificationFee = parseFloat(s.settingValue as string)
        })

        return config
    } catch (error) {
        return DEFAULT_FINANCIAL_SETTINGS
    }
}

export async function updateFinancialSettings(data: FinancialSettings) {
    const session = await getServerSession()
    if (!session?.user?.id) throw new Error("Unauthorized")
    requireAdmin(session)

    const upsertSetting = async (key: string, value: string) => {
        const existing = await db.select().from(systemSettings).where(eq(systemSettings.settingKey, key))
        if (existing.length > 0) {
            await db.update(systemSettings)
                .set({ settingValue: value, updatedBy: session.user.id })
                .where(eq(systemSettings.settingKey, key))
        } else {
            await db.insert(systemSettings).values({
                settingKey: key,
                settingValue: value,
                category: "GENERAL",
                updatedBy: session.user.id
            })
        }
    }

    await upsertSetting("burial_verification_fee", String(data.burialVerificationFee))

    revalidatePath("/dashboard/admin/settings")
    return { success: true }
}
